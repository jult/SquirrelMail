CREATE DATABASE SquirrelMailAuth;

CONNECT SquirrelMailAuth;

CREATE TABLE `smauth` (
   `user` char(8) NOT NULL default '',
   `passwd` char(50) NOT NULL default '',
   `forcepwchange` char(1) NOT NULL default 'N',
   PRIMARY KEY  (user)
) TYPE=MyISAM;


# now manually grant permissions to the database for the user you wish to use.
# mysql -u root -p to get into mysql, then:
# mysql> GRANT select, insert, update, delete ON SquirrelMailAuth.* TO your_user@yourhost identified by 'yourpassword';
