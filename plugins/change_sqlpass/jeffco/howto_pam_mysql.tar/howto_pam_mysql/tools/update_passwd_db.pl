#!/usr/bin/perl

#  This utility will glean user information from /etc/shadow and jam it into
#	the Squirrelmail Auth database.  Make sure to modify the variables
#	below to relect your configuration.  Please note that the very first
#	thing that this utility does is whack the contents of the current
#	table, so be carefull.

# Requirements:  Perl installed in the above location, with DBI installed.

# Use the DBI module
use DBI qw(:sql_types);

# Declare local variables

my ($databaseName, $databaseUser, $databasePw, $dbh);
my ($stmt, $sth, @newRow);
my ($telephone);

# Set the parameter values for the connection
$databaseName = "DBI:mysql:SquirrelMailAuth";
$databaseUser = "root";
$databasePw = "password";
$databaseTableName = "smauth";
$databaseUserField = "user";
$databasePwField = "passwd";
$databasePwChangeField = "forcepwchange";

# Connect to the database
# Note this connection can be used to 
# execute more than one statement
# on any number of tables in the database

$dbh = DBI->connect($databaseName, $databaseUser, 
    $databasePw) || die "Connect failed: $DBI::errstr\n";

# Whack the current table
                $stmt = "DELETE from $databaseTableName";

                # Prepare and execute the SQL query
                $sth = $dbh->prepare($stmt)
                        || die "prepare: $stmt: $DBI::errstr";
                $sth->execute || die "execute: $stmt: $DBI::errstr";



open(SHADOW, "</etc/shadow") || die "Can't open /etc/shadow";

while (<SHADOW>) {

        ($user,$passwd) = split(/:/);

        if ($user ne "root") {
           if ($passwd ne "!!") {
              if ($passwd ne "*") {

		#print "user is $user, crypted/md5 passwd is $passwd\n";

		# Create the statement. 
		$stmt = "INSERT INTO offense ($databaseUserField, $databasePwField, $databasePwChangeField)
			VALUES (\"$user\", \"$passwd\", \"N\")";

		# Prepare and execute the SQL query
		$sth = $dbh->prepare($stmt) 
			|| die "prepare: $stmt: $DBI::errstr";
		$sth->execute || die "execute: $stmt: $DBI::errstr";

}
              }
            }
         }

close(SHADOW);

# Clean up the record set
$sth->finish();
$dbh->disconnect();
